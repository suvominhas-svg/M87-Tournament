# M87 Tournament

A mobile-friendly static tournament UI demo.

## Run
Open `index.html` in a browser, or upload the files to a GitHub repository and enable GitHub Pages.

## Important
This is a front-end demo only. Registration is not stored or sent to a server. It has no paid entry, cash prizes, wallet, or payment processing. Do not collect sensitive personal information.
